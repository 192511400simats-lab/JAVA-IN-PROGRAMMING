import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

class FeeService {
    // Replace these settings with your local MySQL database details.
    private static final String URL = "jdbc:mysql://localhost:3306/simats";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public String payFee(String regNo, String amountText) {
        if (regNo == null || regNo.trim().isEmpty()) {
            return "Enter the register number.";
        }

        final double amount;
        try {
            amount = Double.parseDouble(amountText.trim());
        } catch (NumberFormatException e) {
            return "Enter a valid numeric amount.";
        }

        if (amount <= 0) {
            return "Amount must be greater than zero.";
        }

        String sql = "INSERT INTO fees (reg_no, amount) VALUES (?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, regNo.trim());
            statement.setDouble(2, amount);
            statement.executeUpdate();
            return "Payment recorded successfully.";
        } catch (SQLException e) {
            return "Payment could not be recorded: " + e.getMessage();
        }
    }

    public String getReceipt(String regNo) {
        String sql = "SELECT reg_no, amount, paid_at FROM fees WHERE reg_no=? ORDER BY paid_at DESC LIMIT 1";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, regNo.trim());
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return "Register No: " + rs.getString("reg_no")
                            + "\nAmount: Rs. " + rs.getDouble("amount")
                            + "\nDate: " + rs.getTimestamp("paid_at");
                }
                return "No receipt found.";
            }
        } catch (SQLException e) {
            return "Receipt error: " + e.getMessage();
        }
    }
}

public class FeeWindow extends Frame {
    private final TextField regNo = new TextField(18);
    private final TextField amount = new TextField(18);
    private final Label status = new Label("Enter fee details.");
    private final FeeService service = new FeeService();

    public FeeWindow() {
        super("Student Fee Payment");
        setLayout(new BorderLayout(8, 8));

        Panel form = new Panel(new GridLayout(2, 2, 8, 8));
        form.add(new Label("Register number:"));
        form.add(regNo);
        form.add(new Label("Amount (Rs.):"));
        form.add(amount);

        Panel buttons = new Panel(new FlowLayout());
        Button pay = new Button("Pay");
        Button clear = new Button("Clear");
        Button receipt = new Button("Receipt");
        buttons.add(pay);
        buttons.add(clear);
        buttons.add(receipt);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.NORTH);
        add(status, BorderLayout.SOUTH);

        pay.addActionListener(e -> {
            status.setText("Processing...");
            // AWT demo keeps the service call simple. In a production app,
            // execute database work in a background worker.
            status.setText(service.payFee(regNo.getText(), amount.getText()));
        });

        clear.addActionListener(e -> {
            regNo.setText("");
            amount.setText("");
            status.setText("Fields cleared.");
        });

        receipt.addActionListener(e ->
                status.setText(service.getReceipt(regNo.getText())));

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setSize(430, 190);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new FeeWindow().setVisible(true));
    }
}
