import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class Registration {
    final String studentId;
    final String studentName;
    final String eventName;

    Registration(String studentId, String studentName, String eventName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.eventName = eventName;
    }
}

class RegistrationDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/campus_events";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    void register(Registration r) throws SQLException {
        String sql = "INSERT INTO registrations(student_id, student_name, event_name) VALUES(?,?,?)";
        try (Connection c = connect();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.studentId);
            ps.setString(2, r.studentName);
            ps.setString(3, r.eventName);
            ps.executeUpdate();
        }
    }

    DefaultTableModel findByEvent(String event) throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"ID", "Student ID", "Student Name", "Event", "Registered At"}, 0);
        String sql = event.equals("All")
                ? "SELECT * FROM registrations ORDER BY registration_id DESC"
                : "SELECT * FROM registrations WHERE event_name=? ORDER BY registration_id DESC";

        try (Connection c = connect();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (!event.equals("All")) ps.setString(1, event);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("registration_id"),
                        rs.getString("student_id"),
                        rs.getString("student_name"),
                        rs.getString("event_name"),
                        rs.getTimestamp("registered_at")
                    });
                }
            }
        }
        return model;
    }
}

class RegistrationService {
    private final RegistrationDAO dao = new RegistrationDAO();

    void register(String id, String name, String event) throws Exception {
        if (id.trim().isEmpty() || name.trim().isEmpty() || event.trim().isEmpty()) {
            throw new IllegalArgumentException("All fields are required.");
        }
        dao.register(new Registration(id.trim(), name.trim(), event));
    }

    DefaultTableModel filter(String event) throws SQLException {
        return dao.findByEvent(event);
    }
}

public class CampusEventApp extends JFrame {
    private final JTextField studentId = new JTextField(12);
    private final JTextField studentName = new JTextField(12);
    private final JComboBox<String> event = new JComboBox<>(
            new String[]{"Tech Fest", "Cultural Fest", "Sports Meet"});
    private final JComboBox<String> filter = new JComboBox<>(
            new String[]{"All", "Tech Fest", "Cultural Fest", "Sports Meet"});
    private final JTable table = new JTable(new DefaultTableModel(
            new Object[]{"ID", "Student ID", "Student Name", "Event", "Registered At"}, 0));
    private final JLabel status = new JLabel("Ready");
    private final RegistrationService service = new RegistrationService();

    public CampusEventApp() {
        super("Campus Event Registration");
        setLayout(new BorderLayout(8, 8));

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exportItem = new JMenuItem("Export table to CSV");
        JMenuItem exitItem = new JMenuItem("Exit");
        fileMenu.add(exportItem);
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        form.add(new JLabel("Student ID:"));
        form.add(studentId);
        form.add(new JLabel("Name:"));
        form.add(studentName);
        form.add(new JLabel("Event:"));
        form.add(event);
        JButton register = new JButton("Register");
        form.add(register);

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Filter event:"));
        filterPanel.add(filter);
        JButton refresh = new JButton("Refresh");
        filterPanel.add(refresh);

        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.NORTH);
        north.add(filterPanel, BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);

        register.addActionListener(e -> registerStudent());
        refresh.addActionListener(e -> loadTable());
        filter.addActionListener(e -> loadTable());
        exportItem.addActionListener(e -> exportCsv());
        exitItem.addActionListener(e -> dispose());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 500);
        setLocationRelativeTo(null);
        loadTable();
    }

    // SwingWorker keeps JDBC operations off the event-dispatch thread.
    private void registerStudent() {
        String id = studentId.getText();
        String name = studentName.getText();
        String selectedEvent = (String) event.getSelectedItem();

        new SwingWorker<String, Void>() {
            protected String doInBackground() throws Exception {
                service.register(id, name, selectedEvent);
                return "Registration successful.";
            }

            protected void done() {
                try {
                    status.setText(get());
                    loadTable();
                } catch (Exception ex) {
                    Throwable cause = ex.getCause();
                    String message = cause == null ? ex.getMessage() : cause.getMessage();
                    if (message != null && message.toLowerCase().contains("duplicate")) {
                        status.setText("Duplicate: this student is already registered for this event.");
                    } else {
                        status.setText("Registration failed: " + message);
                    }
                }
            }
        }.execute();
    }

    private void loadTable() {
        String selected = (String) filter.getSelectedItem();
        if (selected == null) selected = "All";
        final String choice = selected;

        new SwingWorker<DefaultTableModel, Void>() {
            protected DefaultTableModel doInBackground() throws Exception {
                return service.filter(choice);
            }

            protected void done() {
                try {
                    table.setModel(get());
                    status.setText("Registration list loaded.");
                } catch (Exception ex) {
                    status.setText("Database load error: " + ex.getMessage());
                }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("registrations.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        try (FileWriter writer = new FileWriter(chooser.getSelectedFile())) {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            for (int col = 0; col < model.getColumnCount(); col++) {
                writer.write(model.getColumnName(col) + (col == model.getColumnCount() - 1 ? "\n" : ","));
            }
            for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                    String value = String.valueOf(model.getValueAt(row, col)).replace(",", " ");
                    writer.write(value + (col == model.getColumnCount() - 1 ? "\n" : ","));
                }
            }
            status.setText("CSV exported.");
        } catch (IOException ex) {
            status.setText("Export error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CampusEventApp().setVisible(true));
    }
}
