import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LibrarySearchScreen extends JFrame {
    private final JTextField searchField = new JTextField(22);
    private final JComboBox<String> category =
            new JComboBox<>(new String[]{"All", "Java", "Computer Science", "Networking"});
    private final JLabel status = new JLabel("Ready");
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Book ID", "Title", "Category", "Availability"}, 0);
    private final JTable results = new JTable(model);

    public LibrarySearchScreen() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8, 8));

        JLabel title = new JLabel("Campus Library", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(category);
        JButton search = new JButton("Search");
        searchPanel.add(search);
        add(searchPanel, BorderLayout.BEFORE_FIRST_LINE);

        model.addRow(new Object[]{"B101", "Java Programming", "Java", "Available"});
        model.addRow(new Object[]{"B102", "Computer Networks", "Networking", "Issued"});
        model.addRow(new Object[]{"B103", "Data Structures", "Computer Science", "Available"});

        add(new JScrollPane(results), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prev = new JButton("Prev");
        JButton next = new JButton("Next");
        JButton reserve = new JButton("Reserve");
        actions.add(prev);
        actions.add(next);
        actions.add(reserve);

        JPanel south = new JPanel(new BorderLayout());
        south.add(actions, BorderLayout.CENTER);
        south.add(status, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        search.addActionListener(e -> {
            status.setText("Search: " + searchField.getText()
                    + " | Category: " + category.getSelectedItem());
        });
        prev.addActionListener(e -> status.setText("Previous page selected."));
        next.addActionListener(e -> status.setText("Next page selected."));
        reserve.addActionListener(e -> {
            int row = results.getSelectedRow();
            status.setText(row >= 0 ? "Reserved: " + model.getValueAt(row, 1)
                    : "Select a book first.");
        });

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(720, 450);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearchScreen().setVisible(true));
    }
}
