import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class AppointmentDesk extends JFrame {
    private final JTextField patientId = new JTextField(12);
    private final JComboBox<String> department =
            new JComboBox<>(new String[]{"Cardiology", "Dermatology", "Orthopedics"});
    private final JComboBox<String> doctor = new JComboBox<>();
    private final JComboBox<String> slot =
            new JComboBox<>(new String[]{"09:00 AM", "10:30 AM", "02:00 PM"});
    private final JLabel message = new JLabel("Enter patient details.");
    private boolean bookingInProgress = false;

    private final Map<String, List<String>> doctors = new HashMap<>();

    public AppointmentDesk() {
        super("Hospital Appointment Desk");
        doctors.put("Cardiology", Arrays.asList("Dr. Kumar", "Dr. Meena"));
        doctors.put("Dermatology", Arrays.asList("Dr. Ravi", "Dr. Priya"));
        doctors.put("Orthopedics", Arrays.asList("Dr. Arun", "Dr. Divya"));

        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        form.add(new JLabel("Patient ID:")); form.add(patientId);
        form.add(new JLabel("Department:")); form.add(department);
        form.add(new JLabel("Doctor:")); form.add(doctor);
        form.add(new JLabel("Time slot:")); form.add(slot);

        JButton book = new JButton("Book Appointment");
        JPanel bottom = new JPanel(new FlowLayout());
        bottom.add(book);
        bottom.add(message);

        add(form, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        department.addActionListener(e -> refreshDoctors());
        book.addActionListener(e -> bookAppointment());
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (bookingInProgress) {
                    int choice = JOptionPane.showConfirmDialog(
                            AppointmentDesk.this,
                            "A booking is in progress. Close anyway?",
                            "Confirm close", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) dispose();
                } else {
                    dispose();
                }
            }
        });

        refreshDoctors();
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(570, 260);
        setLocationRelativeTo(null);
    }

    private void refreshDoctors() {
        doctor.removeAllItems();
        List<String> names = doctors.get((String) department.getSelectedItem());
        if (names != null) {
            for (String name : names) doctor.addItem(name);
        }
    }

    private void bookAppointment() {
        String id = patientId.getText().trim();
        if (id.isEmpty()) {
            message.setText("Patient ID is required.");
            return;
        }
        bookingInProgress = true;
        String summary = "Appointment booked for " + id + " with "
                + doctor.getSelectedItem() + " at " + slot.getSelectedItem();
        JOptionPane.showMessageDialog(this, summary);
        message.setText("Booking completed.");
        bookingInProgress = false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppointmentDesk().setVisible(true));
    }
}
