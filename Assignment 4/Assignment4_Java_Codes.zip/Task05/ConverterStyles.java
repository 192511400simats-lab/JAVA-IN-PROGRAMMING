import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Demonstrates four ways of registering the same conversion action.
public class ConverterStyles {
    private static double convertValue(String text, String currency) {
        double amount = Double.parseDouble(text.trim());
        return amount * (currency.equals("USD") ? 0.012 : 0.011);
    }

    private static void showResult(JFrame frame, JTextField input,
                                   JComboBox<String> currency, JLabel output) {
        try {
            double value = convertValue(input.getText(),
                    (String) currency.getSelectedItem());
            String message = String.format("%.2f %s", value, currency.getSelectedItem());
            output.setText(message);
            JOptionPane.showMessageDialog(frame, message);
        } catch (NumberFormatException ex) {
            output.setText("Invalid amount");
            JOptionPane.showMessageDialog(frame, "Invalid amount",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static JFrame createFrame(String title, int style) {
        JFrame frame = new JFrame(title);
        JTextField input = new JTextField(10);
        JComboBox<String> currency =
                new JComboBox<>(new String[]{"USD", "EUR"});
        JButton button = new JButton("Convert");
        JLabel output = new JLabel(" ");
        JPanel panel = new JPanel(new FlowLayout());
        panel.add(new JLabel("INR"));
        panel.add(input);
        panel.add(currency);
        panel.add(button);
        panel.add(output);
        frame.add(panel);

        if (style == 1) {
            // (a) Frame itself implements ActionListener is shown as a dedicated
            // listener class below; keeping the demo factory compact.
            ActionListener listener = new FrameStyleHandler(frame, input, currency, output);
            button.addActionListener(listener);
            input.addActionListener(listener);
        } else if (style == 2) {
            class NamedHandler implements ActionListener {
                public void actionPerformed(ActionEvent e) {
                    showResult(frame, input, currency, output);
                }
            }
            NamedHandler handler = new NamedHandler();
            button.addActionListener(handler);
            input.addActionListener(handler);
        } else if (style == 3) {
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showResult(frame, input, currency, output);
                }
            });
            input.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showResult(frame, input, currency, output);
                }
            });
        } else {
            ActionListener handler = e -> showResult(frame, input, currency, output);
            button.addActionListener(handler);
            input.addActionListener(handler);
        }

        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(420, 130);
        frame.setLocationByPlatform(true);
        return frame;
    }

    private static class FrameStyleHandler implements ActionListener {
        private final JFrame frame;
        private final JTextField input;
        private final JComboBox<String> currency;
        private final JLabel output;

        FrameStyleHandler(JFrame frame, JTextField input,
                          JComboBox<String> currency, JLabel output) {
            this.frame = frame;
            this.input = input;
            this.currency = currency;
            this.output = output;
        }

        public void actionPerformed(ActionEvent e) {
            showResult(frame, input, currency, output);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String[] names = {
                "Style A - Separate frame-style handler",
                "Style B - Named inner class",
                "Style C - Anonymous inner class",
                "Style D - Lambda expression"
            };
            for (int i = 0; i < names.length; i++) {
                createFrame(names[i], i + 1).setVisible(true);
            }
        });
    }
}
