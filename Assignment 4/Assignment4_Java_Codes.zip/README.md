# Programming in Java – Assignment 4 (CO4)

Contains Java implementations for all six tasks in Assignment 4.

## Requirements
- JDK 8 or later
- MySQL Server and MySQL Connector/J for Tasks 1 and 6 if database functions are to be tested
- A graphical desktop environment to run AWT/Swing windows

## Task files
| Task | Source file | Main coverage |
|---|---|---|
| 1 | `Task01/FeeWindow.java` | Fee GUI, separate FeeService, validation, PreparedStatement, receipt |
| 2 | `Task02/AppointmentDesk.java` | Appointment events, department-dependent doctor list, booking and close confirmation |
| 3 | `Task03/LibrarySearchScreen.java` | Nested panels and resizing-friendly BorderLayout/FlowLayout |
| 4 | `Task04/DrawPad.java` | MouseAdapter, mouseClicked, repaint and persistent points in paint |
| 5 | `Task05/Converter.java` | Lambda listener shared by Convert and Enter, formatted output and dialogs |
| 5 | `Task05/ConverterStyles.java` | Demonstration of separate handler, named inner class, anonymous class and lambda |
| 6 | `Task06/CampusEventApp.java` | Layered Swing/JDBC app, JTable, filtering, CSV export, SwingWorker |
| 6 | `Task06/schema.sql` | MySQL database and table |

## Compile and run GUI tasks
From each task folder:
```bash
javac FileName.java
java ClassName
```

## Database setup for Task 1
1. Create a MySQL database named `simats`.
2. Create the table:
```sql
CREATE TABLE fees (
  fee_id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(30) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
3. Edit URL, USER and PASSWORD in `FeeWindow.java`.
4. Add MySQL Connector/J to the classpath.

## Database setup for Task 6
1. Run `Task06/schema.sql` in MySQL.
2. Edit URL, USER and PASSWORD in `RegistrationDAO` inside `CampusEventApp.java`.
3. Add MySQL Connector/J to the classpath. Example on Windows:
```bash
javac -cp ".;mysql-connector-j-8.x.x.jar" CampusEventApp.java
java -cp ".;mysql-connector-j-8.x.x.jar" CampusEventApp
```
On macOS/Linux, replace the semicolon in the classpath with a colon.

## Important notes
- Task 1 and Task 6 require a configured MySQL server for their database features.
- Task 2 uses an in-memory doctor list to demonstrate the required event-driven behaviour; it does not require a database.
- Task 5 uses fixed illustrative INR conversion rates from the assignment prompt. They are not live exchange rates.
- Task 6 uses a unique database key on (student_id, event_name) to prevent duplicate registrations. SwingWorker keeps database work away from the Swing event-dispatch thread.
- Task 3's three requested screenshots must be captured by running the program at three different window sizes.
