import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

class InsufficientFundsException extends Exception {
    InsufficientFundsException(String message) {
        super(message);
    }
}

public class ATMWithdrawal {
    private static final int BALANCE = 10000;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Scanner cardReader = null;

        try {
            // The card-reader file represents a connected ATM card reader.
            cardReader = new Scanner(new File("card-reader.txt"));

            System.out.print("Enter account number: ");
            String accountNumber = input.nextLine();

            System.out.print("Enter withdrawal amount: ");
            int amount = Integer.parseInt(input.nextLine());

            if (accountNumber.trim().isEmpty()) {
                throw new IllegalArgumentException("Account number cannot be empty");
            }
            if (amount <= 0) {
                throw new IllegalArgumentException("Withdrawal amount must be positive");
            }
            if (amount > BALANCE) {
                throw new InsufficientFundsException("Insufficient account balance");
            }

            System.out.println("Account: " + accountNumber);
            System.out.println("Cash dispensed: Rs. " + amount);
            System.out.println("Remaining balance: Rs. " + (BALANCE - amount));

        } catch (FileNotFoundException e) {
            System.out.println("ATM error: Card-reader file is missing.");
        } catch (NumberFormatException | IllegalArgumentException e) {
            System.out.println("Invalid input: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Transaction declined: " + e.getMessage());
        } finally {
            if (cardReader != null) {
                cardReader.close();
            }
            System.out.println("ATM session ended.");
        }
    }
}
