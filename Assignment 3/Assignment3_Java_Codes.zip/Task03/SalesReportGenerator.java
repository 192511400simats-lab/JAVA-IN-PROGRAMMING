import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class SalesReportGenerator {
    private static final List<String> INPUT_FILES =
            Arrays.asList("store1.txt", "store2.txt", "store3.txt");

    // Creates small sample input files so the program can run immediately.
    private static void createSampleFiles() throws IOException {
        String[][] data = {
            {"1200.50", "800.00"},
            {"450.00", "900.25"},
            {"300.00", "650.00"}
        };

        for (int i = 0; i < INPUT_FILES.size(); i++) {
            try (BufferedWriter writer = new BufferedWriter(
                    new FileWriter(INPUT_FILES.get(i)))) {
                for (String value : data[i]) {
                    writer.write(value);
                    writer.newLine();
                }
            }
        }
    }

    // Version 1: manual close in finally.
    private static void generateManual(String outputFile) {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(outputFile));
            double total = 0;

            for (String file : INPUT_FILES) {
                BufferedReader reader = null;
                try {
                    reader = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        total += Double.parseDouble(line);
                    }
                } catch (IOException | NumberFormatException e) {
                    System.out.println("Manual version: problem in " + file
                            + " - " + e.getMessage());
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            System.out.println("Could not close " + file);
                        }
                    }
                }
            }
            writer.write("Total sales = " + total);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Manual report error: " + e.getMessage());
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Could not close output file.");
                }
            }
        }
    }

    // Version 2: try-with-resources closes each file automatically.
    private static void generateTryWithResources(String outputFile) {
        double total = 0;

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(outputFile))) {
            for (String file : INPUT_FILES) {
                try (BufferedReader reader = new BufferedReader(
                        new FileReader(file))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        total += Double.parseDouble(line);
                    }
                } catch (IOException | NumberFormatException e) {
                    System.out.println("Try-with-resources: problem in " + file
                            + " - " + e.getMessage());
                }
            }
            writer.write("Total sales = " + total);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Try-with-resources report error: "
                    + e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        createSampleFiles();
        generateManual("manual-report.txt");
        generateTryWithResources("safe-report.txt");

        System.out.println("Manual report:");
        printFile("manual-report.txt");
        System.out.println("Try-with-resources report:");
        printFile("safe-report.txt");
    }

    private static void printFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Unable to read report: " + e.getMessage());
        }
    }
}
