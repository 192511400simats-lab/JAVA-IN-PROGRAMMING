import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class ProcessingResult {
    final String fileName;
    final boolean success;
    final String message;

    ProcessingResult(String fileName, boolean success, String message) {
        this.fileName = fileName;
        this.success = success;
        this.message = message;
    }
}

class ScoreTask implements Callable<ProcessingResult> {
    private final Path file;

    ScoreTask(Path file) {
        this.file = file;
    }

    @Override
    public ProcessingResult call() {
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String line = reader.readLine();
            if (line == null) {
                return new ProcessingResult(file.getFileName().toString(),
                        false, "Empty score file");
            }

            int score = Integer.parseInt(line.trim());
            if (score < 0 || score > 100) {
                return new ProcessingResult(file.getFileName().toString(),
                        false, "Score must be between 0 and 100");
            }

            String grade = score >= 90 ? "A" : score >= 75 ? "B"
                    : score >= 50 ? "C" : "Fail";

            return new ProcessingResult(file.getFileName().toString(),
                    true, "Score=" + score + ", Grade=" + grade);

        } catch (IOException | NumberFormatException e) {
            return new ProcessingResult(file.getFileName().toString(),
                    false, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}

public class ResultProcessor {
    private static void createSampleFiles(Path directory) throws IOException {
        Files.createDirectories(directory);
        for (int i = 1; i <= 10; i++) {
            Path file = directory.resolve("student" + i + ".txt");
            String score = (i == 4) ? "invalid-score" : String.valueOf(45 + i * 5);
            Files.write(file, score.getBytes());
        }
        // student_missing.txt is deliberately not created.
    }

    private static void process(Path directory, int poolSize) throws Exception {
        long start = System.currentTimeMillis();
        ExecutorService executor = Executors.newFixedThreadPool(poolSize);
        ConcurrentLinkedQueue<ProcessingResult> results =
                new ConcurrentLinkedQueue<>();
        List<Future<ProcessingResult>> futures = new ArrayList<>();

        try {
            for (int i = 1; i <= 10; i++) {
                Path file = directory.resolve("student" + i + ".txt");
                futures.add(executor.submit(new ScoreTask(file)));
            }

            // Also submit one deliberately missing file to test fault handling.
            futures.add(executor.submit(
                    new ScoreTask(directory.resolve("student_missing.txt"))));

            for (Future<ProcessingResult> future : futures) {
                try {
                    results.add(future.get());
                } catch (Exception e) {
                    results.add(new ProcessingResult("Unknown", false,
                            "Unexpected task failure: " + e.getMessage()));
                }
            }
        } finally {
            executor.shutdown();
        }

        int success = 0;
        int failure = 0;
        for (ProcessingResult result : results) {
            if (result.success) {
                success++;
                System.out.println("SUCCESS " + result.fileName + ": "
                        + result.message);
            } else {
                failure++;
                System.out.println("FAILED  " + result.fileName + ": "
                        + result.message);
            }
        }

        long elapsed = System.currentTimeMillis() - start;
        System.out.println("Thread pool size: " + poolSize);
        System.out.println("Successful files: " + success);
        System.out.println("Failed files: " + failure);
        System.out.println("Total processed: " + (success + failure));
        System.out.println("Time taken: " + elapsed + " ms");
    }

    public static void main(String[] args) throws Exception {
        Path directory = Paths.get("score-files");
        createSampleFiles(directory);

        int poolSize = 4;
        if (args.length > 0) {
            poolSize = Integer.parseInt(args[0]);
        }
        if (poolSize < 1) {
            throw new IllegalArgumentException("Pool size must be at least 1");
        }

        process(directory, poolSize);
    }
}
