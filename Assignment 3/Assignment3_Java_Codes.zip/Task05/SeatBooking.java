public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;

    SeatBooking(int seats) {
        booked = new boolean[seats];
    }

    // The check-and-book operation is atomic because the method is synchronized.
    public synchronized void book(int seatNumber) {
        if (seatNumber < 0 || seatNumber >= booked.length) {
            return;
        }

        if (!booked[seatNumber]) {
            booked[seatNumber] = true;
            bookingsMade++;
            System.out.println("Seat " + (seatNumber + 1) + " booked.");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];

        for (int i = 0; i < users.length; i++) {
            final int seat = i % 10;
            users[i] = new Thread(() -> screen.book(seat));
            users[i].start();
        }

        for (Thread user : users) {
            user.join();
        }

        System.out.println("Seats sold: " + screen.bookingsMade);
    }
}
