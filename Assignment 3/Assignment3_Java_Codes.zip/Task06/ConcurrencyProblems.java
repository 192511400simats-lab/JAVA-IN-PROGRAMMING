import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Wallet {
    private final int id;
    private int balance;
    private final Lock lock = new ReentrantLock();

    Wallet(int id, int balance) {
        this.id = id;
        this.balance = balance;
    }

    int getId() {
        return id;
    }

    int getBalance() {
        return balance;
    }

    Lock getLock() {
        return lock;
    }

    void subtract(int amount) {
        balance -= amount;
    }

    void add(int amount) {
        balance += amount;
    }
}

class WalletTransfer {
    // Lock accounts in ascending ID order to prevent circular wait.
    static void transfer(Wallet from, Wallet to, int amount) {
        Wallet first = from.getId() < to.getId() ? from : to;
        Wallet second = from.getId() < to.getId() ? to : from;

        first.getLock().lock();
        second.getLock().lock();

        try {
            if (amount > 0 && from.getBalance() >= amount) {
                from.subtract(amount);
                to.add(amount);
                System.out.println("Transferred Rs. " + amount
                        + " from wallet " + from.getId()
                        + " to wallet " + to.getId());
            }
        } finally {
            second.getLock().unlock();
            first.getLock().unlock();
        }
    }
}

class TokenCounter {
    private final int[] buffer = new int[5];
    private int count = 0;
    private int in = 0;
    private int out = 0;

    public synchronized void put(int token) throws InterruptedException {
        while (count == buffer.length) {
            wait();
        }

        buffer[in] = token;
        in = (in + 1) % buffer.length;
        count++;
        notifyAll();
    }

    public synchronized int take() throws InterruptedException {
        while (count == 0) {
            wait();
        }

        int token = buffer[out];
        out = (out + 1) % buffer.length;
        count--;
        notifyAll();
        return token;
    }
}

public class ConcurrencyProblems {
    public static void main(String[] args) throws InterruptedException {
        // Part A: concurrent wallet transfers without deadlock.
        Wallet wallet1 = new Wallet(1, 1000);
        Wallet wallet2 = new Wallet(2, 1000);

        Thread transfer1 = new Thread(
                () -> WalletTransfer.transfer(wallet1, wallet2, 100));
        Thread transfer2 = new Thread(
                () -> WalletTransfer.transfer(wallet2, wallet1, 150));

        transfer1.start();
        transfer2.start();
        transfer1.join();
        transfer2.join();

        System.out.println("Wallet 1 balance: Rs. " + wallet1.getBalance());
        System.out.println("Wallet 2 balance: Rs. " + wallet2.getBalance());

        // Part B: producer-consumer token counter with capacity 5.
        TokenCounter counter = new TokenCounter();
        int[] collected = new int[2];

        Thread cook = new Thread(() -> {
            try {
                for (int token = 1; token <= 20; token++) {
                    counter.put(token);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        Thread[] students = new Thread[2];
        for (int s = 0; s < students.length; s++) {
            final int id = s;
            students[s] = new Thread(() -> {
                try {
                    for (int k = 0; k < 10; k++) {
                        collected[id] += counter.take();
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }

        cook.start();
        for (Thread student : students) {
            student.start();
        }

        cook.join();
        for (Thread student : students) {
            student.join();
        }

        System.out.println("Sum of tokens collected: "
                + (collected[0] + collected[1]) + " (expected 210)");
    }
}
