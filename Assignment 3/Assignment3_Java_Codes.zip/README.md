# Programming in Java – Assignment 3 (CO3)

This folder contains one independent Java program for each question (Q1–Q7).

## Requirements
- JDK 8 or later
- A terminal / command prompt

## Compile and run
Open the required task folder, then run:

```bash
javac FileName.java
java ClassName
```

| Task | File | Main concepts |
|---|---|---|
| Q1 | `ATMWithdrawal.java` | try, catch, multi-catch, finally, checked and unchecked exceptions |
| Q2 | `StorageDemo.java` | User-defined checked exceptions, throw, throws, exception chaining |
| Q3 | `SalesReportGenerator.java` | Manual resource closing and try-with-resources |
| Q4 | `ThreadLifeCycleDemo.java` | Thread, Runnable, start, sleep, join, isAlive |
| Q5 | `SeatBooking.java` | Race condition and synchronized method |
| Q6 | `ConcurrencyProblems.java` | Deadlock prevention, lock ordering, wait, notifyAll, producer-consumer |
| Q7 | `ResultProcessor.java` | ExecutorService, Callable, Future, ConcurrentLinkedQueue, fault handling |

## Notes
- Q1 expects a `card-reader.txt` file in the program's working directory. Create an empty text file with that name before running the program. The missing-file case is handled intentionally.
- Q3 creates sample store input files and two report files automatically.
- Q6 demonstrates wallet transfers with consistent lock ordering and a bounded producer-consumer buffer.
- Q7 creates sample score files automatically. One file contains invalid data and one file is deliberately missing to demonstrate fault handling. You can choose the thread-pool size, for example `java ResultProcessor 4`.
- Each task is a separate program. Do not compile all source files together because some tasks use their own public class.
