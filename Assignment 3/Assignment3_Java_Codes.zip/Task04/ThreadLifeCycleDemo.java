class ScannerStation extends Thread {
    private final int scripts;

    ScannerStation(String name, int scripts) {
        super(name);
        this.scripts = scripts;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= scripts; i++) {
                Thread.sleep(200);
            }
            System.out.println(getName() + " scanned " + scripts + " scripts.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println(getName() + " was interrupted.");
        }
    }
}

class RunnableStation implements Runnable {
    private final String stationName;
    private final int scripts;

    RunnableStation(String stationName, int scripts) {
        this.stationName = stationName;
        this.scripts = scripts;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= scripts; i++) {
                Thread.sleep(150);
            }
            System.out.println(stationName + " scanned " + scripts + " scripts.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

public class ThreadLifeCycleDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];

        // Two threads created by extending Thread.
        stations[0] = new ScannerStation("Station 1", 5);
        stations[1] = new ScannerStation("Station 2", 4);

        // Two threads created by implementing Runnable.
        stations[2] = new Thread(new RunnableStation("Station 3", 6));
        stations[3] = new Thread(new RunnableStation("Station 4", 3));

        for (Thread station : stations) {
            station.start();
        }

        System.out.println("Station 1 alive: " + stations[0].isAlive());

        for (Thread station : stations) {
            station.join();
        }

        System.out.println("All scanner stations completed.");
    }
}
