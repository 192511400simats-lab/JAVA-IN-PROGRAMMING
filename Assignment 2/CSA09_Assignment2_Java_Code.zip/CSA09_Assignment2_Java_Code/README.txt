CSA09 – Programming in Java – Assignment 2 (CO2)
Java source files for Q1–Q7

How to run:
1. Install JDK 8 or later.
2. Open a terminal in the folder containing a source file.
3. Compile: javac Q1_StringBenchmark.java
4. Run:     java Q1_StringBenchmark
5. Repeat for the other Q files.

Files:
Task01/Q1_StringBenchmark.java       String, StringBuilder and StringBuffer benchmark
Task02/Q2_ListBenchmark.java         ArrayList, LinkedList and ArrayDeque comparison
Task03/Q3_HashSetContract.java       HashSet, equals() and hashCode()
Task04/Q4_MapInventory.java          HashMap, TreeMap and LinkedHashMap
Task05/Q5_GenericLeaderboard.java    Generics and Comparator ranking
Task06/Q6_HospitalTriage.java        PriorityQueue hospital triage
Task07/Q7_RedesignValidation.java    Original versus redesigned ordered-report solution

Important:
- Each file is an independent Java program. Compile and run each one separately.
- Timing values depend on your computer, Java version and current system load. Do not copy
  sample timings from another machine. Run each program repeatedly and record your own results.
- Q7 is an example redesign based on Q4's repeated sorting limitation. You may choose a different
  limitation from your own Q1–Q6 measurements and explain it in your report.
- The assignment requires predictions, test design, repeated measurements, analysis and viva
  explanations in addition to source code.
