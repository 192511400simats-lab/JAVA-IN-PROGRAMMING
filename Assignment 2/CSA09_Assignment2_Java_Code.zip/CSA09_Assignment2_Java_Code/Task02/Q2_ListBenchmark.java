import java.util.*;

public class Q2_ListBenchmark {
    static long time(String label, Runnable action) {
        long start = System.nanoTime();
        action.run();
        long elapsed = System.nanoTime() - start;
        System.out.printf("%-32s %.3f ms%n", label, elapsed / 1_000_000.0);
        return elapsed;
    }

    public static void main(String[] args) {
        int[] sizes = {1000, 10000, 50000};
        for (int n : sizes) {
            System.out.println("\\nPlaylist size: " + n);
            List<Integer> array = new ArrayList<>();
            List<Integer> linked = new LinkedList<>();
            for (int i = 0; i < n; i++) { array.add(i); linked.add(i); }

            time("ArrayList add at end", () -> array.add(-1));
            time("LinkedList add at end", () -> linked.add(-1));
            time("ArrayList insert at front", () -> array.add(0, -1));
            time("LinkedList insert at front", () -> linked.add(0, -1));
            time("ArrayList middle insert", () -> array.add(array.size()/2, -1));
            time("LinkedList middle insert", () -> linked.add(linked.size()/2, -1));
            time("ArrayList get middle", () -> { int x = array.get(array.size()/2); });
            time("LinkedList get middle", () -> { int x = linked.get(linked.size()/2); });
            time("ArrayList full iteration", () -> { long s=0; for(int x:array)s+=x; });
            time("LinkedList full iteration", () -> { long s=0; for(int x:linked)s+=x; });

            ArrayDeque<Integer> upNext = new ArrayDeque<>();
            time("ArrayDeque add/remove ends", () -> {
                for (int i=0; i<n; i++) { upNext.addFirst(i); upNext.addLast(i); }
                while (!upNext.isEmpty()) upNext.removeFirst();
            });
        }
        System.out.println("\\nTypical complexity: ArrayList get O(1), end-add amortized O(1), middle/front edits O(n).");
        System.out.println("LinkedList indexed get O(n), end edits O(1) with endpoints, middle edit O(n) to locate.");
        System.out.println("ArrayDeque end-add/remove O(1) amortized; it is suitable for an Up Next queue.");
    }
}
