import java.util.*;

class Student {
    private final String regNo;
    private final String name;

    Student(String regNo, String name) { this.regNo = regNo; this.name = name; }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student other = (Student) o;
        return Objects.equals(regNo, other.regNo);
    }

    @Override public int hashCode() {
        return Objects.hash(regNo);
    }

    @Override public String toString() { return regNo + " " + name; }
}

public class Q3_HashSetContract {
    public static void main(String[] args) {
        Set<Student> present = new HashSet<>();
        present.add(new Student("192311001", "Arun"));
        present.add(new Student("192311002", "Divya"));
        present.add(new Student("192311001", "Arun"));
        System.out.println("Complete-code test: Unique students: " + present.size());

        Set<Student> test1 = new HashSet<>();
        test1.add(new Student("S1", "A")); test1.add(new Student("S1", "A"));
        System.out.println("Test 1 (same ID twice), predicted 1, observed: " + test1.size());

        Set<Student> test2 = new HashSet<>();
        test2.add(new Student("S1", "A")); test2.add(new Student("S2", "B"));
        test2.add(new Student("S3", "C"));
        System.out.println("Test 2 (different IDs), predicted 3, observed: " + test2.size());

        Set<Student> test3 = new HashSet<>();
        test3.add(new Student("S4", "D")); test3.add(new Student("S4", "Different name"));
        System.out.println("Test 3 (same ID, different name), predicted 1, observed: " + test3.size());
    }
}
