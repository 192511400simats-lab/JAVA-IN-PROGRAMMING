import java.util.StringJoiner;

public class Q1_StringBenchmark {
    static String withPlus(int tickets, int fields) {
        String result = "";
        for (int t = 0; t < tickets; t++) {
            String ticket = "";
            for (int f = 0; f < fields; f++) ticket += "Field" + f + "=" + f + ";";
            result = ticket;
        }
        return result;
    }

    static String withBuilder(int tickets, int fields) {
        String result = "";
        for (int t = 0; t < tickets; t++) {
            StringBuilder b = new StringBuilder();
            for (int f = 0; f < fields; f++) b.append("Field").append(f).append('=').append(f).append(';');
            result = b.toString();
        }
        return result;
    }

    static String withBuffer(int tickets, int fields) {
        String result = "";
        for (int t = 0; t < tickets; t++) {
            StringBuffer b = new StringBuffer();
            for (int f = 0; f < fields; f++) b.append("Field").append(f).append('=').append(f).append(';');
            result = b.toString();
        }
        return result;
    }

    static void measure(String label, Runnable task) {
        long start = System.nanoTime();
        task.run();
        System.out.printf("%s: %.3f ms%n", label, (System.nanoTime() - start) / 1_000_000.0);
    }

    public static void main(String[] args) {
        int[][] workloads = {{1, 5}, {10000, 50}, {2000, 100}};
        for (int[] w : workloads) {
            int tickets = w[0], fields = w[1];
            System.out.println("\\nTickets=" + tickets + ", fields=" + fields);
            measure("String +", () -> withPlus(tickets, fields));
            measure("StringBuilder", () -> withBuilder(tickets, fields));
            measure("StringBuffer", () -> withBuffer(tickets, fields));
        }
        System.out.println("\\nRecommendation: StringBuilder for each private ticket; StringBuffer only when");
        System.out.println("multiple threads truly share the same mutable log buffer. Prefer synchronized logging APIs.");
    }
}
