import java.util.*;

public class Q4_MapInventory {
    static void run(int n) {
        Map<String, Integer> hash = new HashMap<>();
        Map<String, Integer> tree = new TreeMap<>();
        Map<String, Integer> linked = new LinkedHashMap<>();

        for (int i = n - 1; i >= 0; i--) {
            String code = String.format("MED%06d", i);
            hash.put(code, i * 10);
            tree.put(code, i * 10);
            linked.put(code, i * 10);
        }

        String target = String.format("MED%06d", n / 2);
        long start = System.nanoTime();
        for (int i = 0; i < 100000; i++) hash.get(target);
        long lookup = System.nanoTime() - start;

        start = System.nanoTime();
        List<String> codeReport = new ArrayList<>(hash.keySet());
        Collections.sort(codeReport);
        long sortedReport = System.nanoTime() - start;

        start = System.nanoTime();
        for (String key : tree.keySet()) { /* ordered report */ }
        long treeReport = System.nanoTime() - start;

        start = System.nanoTime();
        for (String key : linked.keySet()) { /* insertion-order report */ }
        long insertionReport = System.nanoTime() - start;

        System.out.println("\\nMedicines: " + n);
        System.out.printf("100,000 HashMap lookups: %.3f ms%n", lookup / 1e6);
        System.out.printf("HashMap + sort code report: %.3f ms%n", sortedReport / 1e6);
        System.out.printf("TreeMap code-order report: %.3f ms%n", treeReport / 1e6);
        System.out.printf("LinkedHashMap insertion-order report: %.3f ms%n", insertionReport / 1e6);
        System.out.println("Code order correct: " + new ArrayList<>(tree.keySet()).equals(new ArrayList<>(new TreeSet<>(tree.keySet()))));
    }

    public static void main(String[] args) {
        run(100); run(1000); run(10000);
        System.out.println("\\nUse HashMap for fast lookup, TreeMap for code-sorted reports, LinkedHashMap for insertion order.");
        System.out.println("Hashtable is legacy; modern alternatives offer clearer collection APIs and null-handling behaviour.");
    }
}
