import java.util.*;

/*
 * Day-4 redesign demonstration:
 * Original: store medicines in HashMap and sort all keys every time a code-order report is requested.
 * Redesigned: maintain a TreeMap, which keeps keys ordered as records are inserted.
 * Run repeatedly with the same data size; compare averages on your own machine.
 */
public class Q7_RedesignValidation {
    static Map<String, Integer> buildHash(int n) {
        Map<String, Integer> map = new HashMap<>();
        for (int i = n - 1; i >= 0; i--) map.put(String.format("MED%06d", i), i);
        return map;
    }

    static Map<String, Integer> buildTree(int n) {
        Map<String, Integer> map = new TreeMap<>();
        for (int i = n - 1; i >= 0; i--) map.put(String.format("MED%06d", i), i);
        return map;
    }

    static long originalReport(Map<String, Integer> map) {
        long start = System.nanoTime();
        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        long checksum = 0;
        for (String key : keys) checksum += map.get(key);
        if (checksum < 0) System.out.println(checksum);
        return System.nanoTime() - start;
    }

    static long redesignedReport(Map<String, Integer> map) {
        long start = System.nanoTime();
        long checksum = 0;
        for (Map.Entry<String, Integer> e : map.entrySet()) checksum += e.getValue();
        if (checksum < 0) System.out.println(checksum);
        return System.nanoTime() - start;
    }

    public static void main(String[] args) {
        int[] sizes = {1000, 10000, 50000};
        for (int n : sizes) {
            Map<String, Integer> hash = buildHash(n);
            Map<String, Integer> tree = buildTree(n);

            long oldTotal = 0, newTotal = 0;
            int repetitions = 10;
            for (int r = 0; r < repetitions; r++) {
                oldTotal += originalReport(hash);
                newTotal += redesignedReport(tree);
            }

            System.out.println("\\nRecords: " + n);
            System.out.printf("Original HashMap + sort average: %.3f ms%n", oldTotal / repetitions / 1e6);
            System.out.printf("Redesigned TreeMap report average: %.3f ms%n", newTotal / repetitions / 1e6);
            System.out.println("Note: TreeMap pays O(log n) per insertion and stores ordering links; HashMap report sorting costs O(n log n) each time.");
        }
    }
}
