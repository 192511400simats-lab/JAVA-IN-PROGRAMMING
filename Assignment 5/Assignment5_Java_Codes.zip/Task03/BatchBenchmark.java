import java.sql.*;
import java.util.*;

public class BatchBenchmark {
    static final String URL = "jdbc:mysql://localhost:3306/assignment5";
    static final String USER = "root", PASSWORD = "your_mysql_password";
    public static void main(String[] args) throws Exception {
        try (Connection c = DriverManager.getConnection(URL, USER, PASSWORD)) {
            for (int size : new int[]{1000, 10000, 100000}) {
                try (Statement s = c.createStatement()) { s.executeUpdate("DELETE FROM bus_pass"); }
                List<String[]> rows = new ArrayList<>();
                for (int i = 1; i <= size; i++)
                    rows.add(new String[]{"P" + i, "R" + i, "Student" + i, "" + (i % 20 + 1), "4500.0"});
                long start = System.nanoTime();
                int n = PassLoader.loadAll(c, rows);
                System.out.printf("%d rows inserted in %.3f ms%n", n,
                        (System.nanoTime() - start) / 1_000_000.0);
            }
        }
    }
}
