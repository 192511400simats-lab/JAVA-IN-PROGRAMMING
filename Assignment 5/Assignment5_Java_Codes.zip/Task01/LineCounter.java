import java.io.*;
import java.nio.file.*;

public class LineCounter {
    static long unbuffered(Path p) throws IOException {
        long lines = 0;
        try (InputStream in = new FileInputStream(p.toFile())) {
            int b;
            while ((b = in.read()) != -1) if (b == '\\n') lines++;
        }
        return lines;
    }
    static long buffered(Path p) throws IOException {
        long lines = 0;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(p.toFile()))) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1)
                for (int i = 0; i < n; i++) if (buffer[i] == '\\n') lines++;
        }
        return lines;
    }
    public static void main(String[] args) throws IOException {
        Path p = Paths.get(args.length == 0 ? "attendance.log" : args[0]);
        if (!Files.exists(p)) Files.writeString(p, "Student 1\\nStudent 2\\nStudent 3\\n");
        long t = System.nanoTime(); long a = unbuffered(p); long ta = System.nanoTime() - t;
        t = System.nanoTime(); long b = buffered(p); long tb = System.nanoTime() - t;
        System.out.println("Unbuffered lines: " + a + ", time(ns): " + ta);
        System.out.println("Buffered lines: " + b + ", time(ns): " + tb);
    }
}
