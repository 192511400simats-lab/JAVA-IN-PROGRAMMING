# Assignment 5 – Java Code

## Included
- Task01: PassStore (add/find/list) and buffered/unbuffered line counter.
- Task02: unsafe SQL login vs PreparedStatement and damaged-file test.
- Task03: completed PassLoader TODOs and batch benchmark.
- Task04: CSV-to-MySQL migration, rejected-record report and DatabaseMetaData.
- sql/assignment5.sql: database and table creation script.

## Requirements
- JDK 17 or later recommended.
- MySQL Server and MySQL Connector/J for Tasks 2–4.

## Setup
1. Run `sql/assignment5.sql` in MySQL Workbench.
2. In each JDBC Java file, change USER and PASSWORD to your local MySQL credentials.
3. Add MySQL Connector/J to the classpath.

## Compile examples
Task01:
    javac PassStore.java
    java PassStore

Task02 (compile with Task01 PassStore.java):
    javac -cp .;mysql-connector-j.jar LoginSecurity.java
    javac -cp .;mysql-connector-j.jar DamagedPassFileTest.java

Task03:
    javac PassLoader.java BatchBenchmark.java
    java BatchBenchmark

Task04:
    javac PassLoader.java PassMigration.java
    java PassMigration passes.csv

On macOS/Linux, replace the Windows classpath separator `;` with `:`.

## Important
- Run the timing experiments yourself and record your actual measurements. Do not copy invented timings.
- Task B1 asks for 1 MB, 10 MB and 50 MB line-count tests and search timings for 1,000 to 100,000 records.
- Task B3 asks for Statement, PreparedStatement and batch comparisons at 1,000, 10,000 and 100,000 records. Use your own measurements.
- Task A1–A5 require SIMATS-standard pseudocode and design explanations in the report; Java code is not a substitute.
- The CSV example uses simple comma-separated fields. If names contain commas, use a proper CSV parser or escape/quote fields.
- Use SQL injection tests only on your own local assignment database.
