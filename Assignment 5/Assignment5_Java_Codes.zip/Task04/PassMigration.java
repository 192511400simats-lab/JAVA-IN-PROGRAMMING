import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class PassMigration {
    static final String URL = "jdbc:mysql://localhost:3306/assignment5";
    static final String USER = "root", PASSWORD = "your_mysql_password";

    public static void main(String[] args) throws Exception {
        Path file = Paths.get(args.length == 0 ? "passes.csv" : args[0]);
        List<String[]> valid = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(file)) {
            String line; int lineNo = 0;
            while ((line = r.readLine()) != null) {
                lineNo++;
                String[] p = line.split(",", -1);
                try {
                    if (p.length != 5) throw new IllegalArgumentException("Expected five fields");
                    Integer.parseInt(p[3]);
                    double amount = Double.parseDouble(p[4]);
                    if (amount < 0) throw new IllegalArgumentException("Negative amount");
                    valid.add(p);
                } catch (RuntimeException e) {
                    failed.add("Line " + lineNo + ": " + e.getMessage() + " [" + line + "]");
                }
            }
        }
        try (Connection c = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Migrated records: " + PassLoader.loadAll(c, valid));
            DatabaseMetaData m = c.getMetaData();
            System.out.println("Database: " + m.getDatabaseProductName() + " " + m.getDatabaseProductVersion());
            System.out.println("Driver: " + m.getDriverName() + " " + m.getDriverVersion());
            try (ResultSet t = m.getTables(c.getCatalog(), null, "%", new String[]{"TABLE"})) {
                System.out.println("Tables:");
                while (t.next()) System.out.println(t.getString("TABLE_NAME"));
            }
        }
        System.out.println("Rejected records:");
        if (failed.isEmpty()) System.out.println("None");
        else failed.forEach(System.out::println);
    }
}
