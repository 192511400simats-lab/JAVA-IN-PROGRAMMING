import java.sql.*;

public class LoginSecurity {
    static final String URL = "jdbc:mysql://localhost:3306/assignment5";
    static final String USER = "root";
    static final String PASSWORD = "your_mysql_password";

    static boolean unsafeLogin(String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        try (Connection c = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) {
            return r.next();
        }
    }
    static boolean safeLogin(String id, String pwd) throws SQLException {
        String sql = "SELECT * FROM users WHERE id=? AND pwd=?";
        try (Connection c = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, id); p.setString(2, pwd);
            try (ResultSet r = p.executeQuery()) { return r.next(); }
        }
    }
    public static void main(String[] args) throws SQLException {
        String id = args.length > 0 ? args[0] : "unknown";
        String pwd = args.length > 1 ? args[1] : "' OR '1'='1";
        System.out.println("Unsafe login accepted: " + unsafeLogin(id, pwd));
        System.out.println("PreparedStatement accepted: " + safeLogin(id, pwd));
    }
}
