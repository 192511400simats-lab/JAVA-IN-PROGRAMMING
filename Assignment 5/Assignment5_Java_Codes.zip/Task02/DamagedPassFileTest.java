import java.nio.file.*;
import java.util.Arrays;

public class DamagedPassFileTest {
    public static void main(String[] args) throws Exception {
        Path p = Paths.get("damaged_passes.csv");
        Files.writeString(p, "P1,192311001,Arun,12,4500.0\\n"
                + "P2,WRONG FIELD COUNT\\n"
                + "P3,192311003,Divya,7,not-a-number\\n"
                + "\\nP4,192311004,Kavi,8,3900.0\\n");
        PassStore s = new PassStore(p);
        System.out.println("P1: " + Arrays.toString(s.find("P1")));
        System.out.println("P2: " + Arrays.toString(s.find("P2")));
        System.out.println("P4: " + Arrays.toString(s.find("P4")));
    }
}
