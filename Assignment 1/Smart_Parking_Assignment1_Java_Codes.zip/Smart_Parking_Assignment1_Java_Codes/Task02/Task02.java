// Task 2: Data representation using a jagged array.
public class Task02 {
    public static void main(String[] args) {
        int[] slotsPerFloor = {3, 2, 4};
        String[][] slots = new String[slotsPerFloor.length][];
        for (int f = 0; f < slotsPerFloor.length; f++)
            slots[f] = new String[slotsPerFloor[f]];

        slots[1][0] = "TN02CD2222";
        int floor = 1, slot = 0;
        System.out.println("Vehicle: " + slots[floor][slot]);

        int minutes = 125;
        int billableHours = (minutes + 59) / 60; // ceiling without losing precision
        double ratePerHour = 30.0;
        double fee = billableHours * ratePerHour;
        System.out.println("Billable hours: " + billableHours);
        System.out.println("Parking fee: Rs " + fee);

        // Incorrect: minutes / 60 gives 2, not 3.
        System.out.println("Wrong integer-division hours: " + (minutes / 60));
    }
}
