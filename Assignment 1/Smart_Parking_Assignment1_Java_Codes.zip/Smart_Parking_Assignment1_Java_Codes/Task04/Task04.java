// Task 4: Constructors, this keyword and constructor chaining.
class ParkingTicket {
    private final int ticketNo;
    private final String regNo;
    private final long entryTime;

    ParkingTicket() { this(0, "UNKNOWN", System.currentTimeMillis()); }
    ParkingTicket(int ticketNo, String regNo) {
        this(ticketNo, regNo, System.currentTimeMillis());
    }
    ParkingTicket(int ticketNo, String regNo, long entryTime) {
        this.ticketNo = ticketNo;
        this.regNo = regNo;
        this.entryTime = entryTime;
    }
    void display() {
        System.out.println(ticketNo + " | " + regNo + " | " + entryTime);
    }
}
public class Task04 {
    public static void main(String[] args) {
        ParkingTicket t1 = new ParkingTicket();
        ParkingTicket t2 = new ParkingTicket(1001, "TN01AB1111");
        ParkingTicket t3 = new ParkingTicket(1002, "TN02CD2222", 1760000000000L);
        t1.display(); t2.display(); t3.display();
    }
}
