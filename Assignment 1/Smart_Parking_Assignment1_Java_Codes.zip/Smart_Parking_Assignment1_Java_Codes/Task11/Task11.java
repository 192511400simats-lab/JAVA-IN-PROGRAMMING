// Task 11: Small integrated smart-parking implementation with validation and fee tests.
import java.util.*;

abstract class Vehicle {
    private final String regNo;
    Vehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Invalid registration");
        this.regNo = regNo;
    }
    String getRegNo() { return regNo; }
    abstract double rate();
}
class Bike extends Vehicle { Bike(String r) { super(r); } double rate() { return 10; } }
class Car extends Vehicle { Car(String r) { super(r); } double rate() { return 30; } }
class EV extends Vehicle { EV(String r) { super(r); } double rate() { return 30; } }

class ParkingSystem {
    private final String[][] slots;
    private final Map<String, Vehicle> active = new HashMap<>();
    private final Map<String, Integer> entryMinutes = new HashMap<>();
    private double collection;

    ParkingSystem(int[] capacity) {
        slots = new String[capacity.length][];
        for (int i = 0; i < capacity.length; i++) slots[i] = new String[capacity[i]];
    }
    boolean enter(Vehicle v, int entryMinute) {
        if (active.containsKey(v.getRegNo())) return false;
        for (int f = 0; f < slots.length; f++)
            for (int s = 0; s < slots[f].length; s++)
                if (slots[f][s] == null) {
                    slots[f][s] = v.getRegNo();
                    active.put(v.getRegNo(), v);
                    entryMinutes.put(v.getRegNo(), entryMinute);
                    return true;
                }
        return false;
    }
    double exit(String regNo, int exitMinute) {
        Vehicle v = active.get(regNo);
        if (v == null) return -1;
        int duration = Math.max(0, exitMinute - entryMinutes.get(regNo));
        int hours = (duration + 59) / 60;
        double fee = hours * v.rate();
        for (String[] floor : slots)
            for (int s = 0; s < floor.length; s++)
                if (regNo.equals(floor[s])) floor[s] = null;
        active.remove(regNo);
        entryMinutes.remove(regNo);
        collection += fee;
        return fee;
    }
    double getCollection() { return collection; }
}
public class Task11 {
    public static void main(String[] args) {
        ParkingSystem p = new ParkingSystem(new int[]{1, 2});
        System.out.println("Bike entered: " + p.enter(new Bike("TN01A1"), 0));
        System.out.println("Car entered: " + p.enter(new Car("TN02B2"), 0));
        System.out.println("Duplicate rejected: " + !p.enter(new Car("TN02B2"), 5));
        System.out.println("Bike fee (60 min): Rs " + p.exit("TN01A1", 60));
        System.out.println("Car fee (61 min): Rs " + p.exit("TN02B2", 61));
        System.out.println("Daily collection: Rs " + p.getCollection());
        System.out.println("Unknown vehicle exit: " + p.exit("TN99ZZ9999", 90));
    }
}
