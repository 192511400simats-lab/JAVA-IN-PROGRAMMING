// Task 6: Hierarchical and multilevel inheritance.
class Vehicle {
    protected String regNo;
    Vehicle(String regNo) { this.regNo = regNo; System.out.println("Vehicle constructor"); }
}
class Car extends Vehicle {
    Car(String regNo) { super(regNo); System.out.println("Car constructor"); }
}
class ElectricCar extends Car {
    ElectricCar(String regNo) { super(regNo); System.out.println("ElectricCar constructor"); }
}
class TwoWheeler extends Vehicle {
    TwoWheeler(String regNo) { super(regNo); }
}
public class Task06 {
    public static void main(String[] args) {
        ElectricCar ev = new ElectricCar("TN03C3");
        TwoWheeler bike = new TwoWheeler("TN01A1");
        System.out.println("EV registration: " + ev.regNo);
        System.out.println("Bike registration: " + bike.regNo);
    }
}
