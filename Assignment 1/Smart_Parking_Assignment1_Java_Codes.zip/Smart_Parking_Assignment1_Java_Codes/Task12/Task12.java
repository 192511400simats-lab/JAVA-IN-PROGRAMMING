// Task 12: Adapted design with e-bike, delivery van and one-day visitor pass.
import java.time.LocalTime;

interface Pass {
    boolean isValid();
}
class OneDayPass implements Pass {
    private final boolean valid;
    OneDayPass(boolean valid) { this.valid = valid; }
    public boolean isValid() { return valid; }
}
abstract class Vehicle {
    private final String regNo;
    Vehicle(String regNo) { this.regNo = regNo; }
    String getRegNo() { return regNo; }
    abstract double parkingFee(int minutes, LocalTime entry);
}
class Car extends Vehicle {
    Car(String r) { super(r); }
    double parkingFee(int m, LocalTime t) { return ((m + 59) / 60) * 30.0; }
}
class EBike extends Vehicle {
    EBike(String r) { super(r); }
    double parkingFee(int m, LocalTime t) { return 20.0; } // flat fee
}
class DeliveryVan extends Vehicle {
    DeliveryVan(String r) { super(r); }
    double parkingFee(int m, LocalTime entry) {
        int hours = (m + 59) / 60;
        boolean daytime = !entry.isBefore(LocalTime.of(9, 0))
                       && entry.isBefore(LocalTime.of(17, 0));
        return hours * 30.0 * (daytime ? 2 : 1);
    }
}
class Visitor {
    private final Pass pass;
    Visitor(Pass pass) { this.pass = pass; }
    double finalFee(double normalFee) { return pass != null && pass.isValid() ? 0.0 : normalFee; }
}
public class Task12 {
    public static void main(String[] args) {
        Vehicle car = new Car("TN01A1");
        Vehicle bike = new EBike("TN02B2");
        Vehicle van = new DeliveryVan("TN03C3");
        int minutes = 120;
        LocalTime entry = LocalTime.of(10, 0);
        System.out.println("Car fee: Rs " + car.parkingFee(minutes, entry));
        System.out.println("E-bike fee: Rs " + bike.parkingFee(minutes, entry));
        System.out.println("Delivery van fee: Rs " + van.parkingFee(minutes, entry));
        Visitor visitorWithPass = new Visitor(new OneDayPass(true));
        Visitor visitorWithoutPass = new Visitor(new OneDayPass(false));
        System.out.println("Visitor with day pass: Rs " + visitorWithPass.finalFee(60));
        System.out.println("Visitor without pass: Rs " + visitorWithoutPass.finalFee(60));
    }
}
