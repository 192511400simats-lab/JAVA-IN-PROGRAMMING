// Task 5: Static ticket counter and object life cycle.
class Ticket {
    private static int nextNumber = 1000;
    private final int number;
    Ticket() { number = ++nextNumber; }
    int getNumber() { return number; }
}
class Facility {
    private int occupancy;
    void vehicleEntered() { occupancy++; }
    void vehicleLeft() { if (occupancy > 0) occupancy--; }
    int getOccupancy() { return occupancy; }
}
public class Task05 {
    public static void main(String[] args) {
        Facility north = new Facility(), south = new Facility();
        Ticket t1 = new Ticket(), t2 = new Ticket();
        north.vehicleEntered(); south.vehicleEntered();
        System.out.println("Tickets: " + t1.getNumber() + ", " + t2.getNumber());
        System.out.println("North occupancy: " + north.getOccupancy());
        System.out.println("South occupancy: " + south.getOccupancy());
        t1 = null; // eligible for garbage collection if no other reference exists
    }
}
