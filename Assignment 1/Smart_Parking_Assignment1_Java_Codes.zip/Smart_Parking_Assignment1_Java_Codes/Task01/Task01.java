// Task 1: Identify objects and model their responsibilities.
class Vehicle {
    String regNo, type;
    long entryTime;
    Vehicle(String regNo, String type, long entryTime) {
        this.regNo = regNo; this.type = type; this.entryTime = entryTime;
    }
}
class ParkingSlot {
    int floor, slotNo;
    Vehicle parkedVehicle;
    ParkingSlot(int floor, int slotNo) { this.floor = floor; this.slotNo = slotNo; }
    boolean isFree() { return parkedVehicle == null; }
    void park(Vehicle v) { if (isFree()) parkedVehicle = v; }
    Vehicle release() { Vehicle v = parkedVehicle; parkedVehicle = null; return v; }
}
class ParkingTicket {
    static int nextId = 1000;
    final int ticketNo;
    final Vehicle vehicle;
    final long entryTime;
    ParkingTicket(Vehicle vehicle, long entryTime) {
        this.ticketNo = ++nextId; this.vehicle = vehicle; this.entryTime = entryTime;
    }
}
public class Task01 {
    public static void main(String[] args) {
        Vehicle v = new Vehicle("TN01AB1111", "Car", System.currentTimeMillis());
        ParkingSlot slot = new ParkingSlot(0, 1);
        slot.park(v);
        ParkingTicket ticket = new ParkingTicket(v, v.entryTime);
        System.out.println("Vehicle: " + v.regNo);
        System.out.println("Slot occupied: " + !slot.isFree());
        System.out.println("Ticket: " + ticket.ticketNo);
    }
}
