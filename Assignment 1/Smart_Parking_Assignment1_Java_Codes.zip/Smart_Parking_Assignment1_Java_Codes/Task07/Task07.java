// Task 7: Method overriding and Object class methods.
class Vehicle {
    private final String regNo;
    Vehicle(String regNo) { this.regNo = regNo; }
    double calculateFee(int hours) { return hours * 20.0; }
    @Override public String toString() { return "Vehicle[" + regNo + "]"; }
    @Override public boolean equals(Object obj) {
        if (!(obj instanceof Vehicle)) return false;
        Vehicle other = (Vehicle) obj;
        return regNo.equals(other.regNo);
    }
    @Override public int hashCode() { return regNo.hashCode(); }
}
class Car extends Vehicle {
    Car(String regNo) { super(regNo); }
    @Override double calculateFee(int hours) { return hours * 30.0; }
}
class Bike extends Vehicle {
    Bike(String regNo) { super(regNo); }
    @Override double calculateFee(int hours) { return hours * 10.0; }
}
public class Task07 {
    public static void main(String[] args) {
        Vehicle car = new Car("TN01AB1111");
        Vehicle bike = new Bike("TN02CD2222");
        System.out.println(car + " fee: Rs " + car.calculateFee(2));
        System.out.println(bike + " fee: Rs " + bike.calculateFee(2));
        System.out.println("Equal registration: " +
            new Car("TN03EF3333").equals(new Bike("TN03EF3333")));
    }
}
