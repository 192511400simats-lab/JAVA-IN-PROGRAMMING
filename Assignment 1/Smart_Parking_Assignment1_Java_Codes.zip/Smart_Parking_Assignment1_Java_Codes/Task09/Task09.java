// Task 9: Abstract class and interface.
interface Chargeable {
    double chargingFee(int units);
    default void showChargingMessage() { System.out.println("EV charging available"); }
    static boolean validUnits(int units) { return units >= 0; }
}
abstract class Vehicle {
    protected String regNo;
    Vehicle(String regNo) { this.regNo = regNo; }
    abstract double parkingFee(int hours);
}
class ElectricCar extends Vehicle implements Chargeable {
    ElectricCar(String regNo) { super(regNo); }
    @Override double parkingFee(int hours) { return hours * 30.0; }
    @Override public double chargingFee(int units) {
        if (!Chargeable.validUnits(units)) throw new IllegalArgumentException("Invalid units");
        return units * 12.0;
    }
}
public class Task09 {
    public static void main(String[] args) {
        ElectricCar ev = new ElectricCar("TN03C3");
        ev.showChargingMessage();
        System.out.println("Parking fee: Rs " + ev.parkingFee(2));
        System.out.println("Charging fee: Rs " + ev.chargingFee(5));
    }
}
