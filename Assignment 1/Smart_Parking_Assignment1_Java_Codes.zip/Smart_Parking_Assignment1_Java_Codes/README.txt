CAMPUS SMART-PARKING SYSTEM – JAVA TASK CODES

Each Task folder contains a separate Java program. The programs are independent.

Requirements:
- JDK 8 or later for Tasks 1–7, 9–12.
- JDK 16 or later for Task 8 if using the original pattern-matching instanceof syntax is desired.
  The supplied Task08 code uses ordinary instanceof and casting, so it also compiles on JDK 8+.

Compile and run:
1. Open Command Prompt/Terminal.
2. Move into the required task folder.
3. Compile: javac TaskXX.java
4. Run: java TaskXX

Example:
cd Task03
javac Task03.java
java Task03

Task 3 and Task 8 implement the two "Complete the Code" programs from the assignment.
Task 1, 2, 4–7, 9–10 provide separate demonstrations of the concept assigned to that task.
Task 11 is a compact integrated implementation.
Task 12 demonstrates the changed requirements: e-bike, delivery van and visitor day pass.

Important:
- These are code examples for the programming evidence. The written analysis, pseudocode,
  UML diagram, complexity comparison, test table and design defence requested in the PDF
  must also be included in the report.
- Review and understand each program before submission, and execute them to capture your
  own output screenshots.
