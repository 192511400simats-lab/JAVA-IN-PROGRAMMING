// Task 10: Encapsulation, validation, wrapper class and autoboxing.
class Slot {
    private int slotNumber;
    private Integer floorNumber; // wrapper class example

    Slot(int slotNumber, Integer floorNumber) {
        setSlotNumber(slotNumber);
        setFloorNumber(floorNumber);
    }
    public int getSlotNumber() { return slotNumber; }
    public void setSlotNumber(int slotNumber) {
        if (slotNumber <= 0) throw new IllegalArgumentException("Slot must be positive");
        this.slotNumber = slotNumber;
    }
    public Integer getFloorNumber() { return floorNumber; }
    public void setFloorNumber(Integer floorNumber) {
        if (floorNumber == null || floorNumber < 0)
            throw new IllegalArgumentException("Invalid floor");
        this.floorNumber = floorNumber; // autoboxing/unboxing
    }
}
public class Task10 {
    public static void main(String[] args) {
        Slot s = new Slot(5, 2);
        System.out.println("Floor: " + s.getFloorNumber());
        System.out.println("Slot: " + s.getSlotNumber());
        try { s.setSlotNumber(-1); }
        catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
        Integer a = 1000, b = 1000;
        System.out.println("Use equals(): " + a.equals(b));
    }
}
